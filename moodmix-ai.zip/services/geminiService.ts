import { GoogleGenAI, Type, Schema } from "@google/genai";
import { DrinkRecipe } from "../types";

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const recipeSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    name: { type: Type.STRING, description: "Creative abstract name of the drink" },
    tagline: { type: Type.STRING, description: "Subtitle like 'Midnight Cacao Mild'" },
    description: { type: Type.STRING, description: "Short poetic description of the drink" },
    baseSpirit: { type: Type.STRING, description: "The alcohol base, e.g., Gin, Whiskey, or 'Void Essence' for non-alcoholic" },
    ingredients: { 
      type: Type.ARRAY, 
      items: { type: Type.STRING },
      description: "List of 3-4 creative ingredients"
    },
    flavorProfile: {
      type: Type.OBJECT,
      properties: {
        top: { type: Type.STRING },
        middle: { type: Type.STRING },
        base: { type: Type.STRING }
      },
      required: ["top", "middle", "base"]
    },
    intensity: { type: Type.INTEGER, description: "Intensity from 0 to 100" },
    abv: { type: Type.STRING, description: "Alcohol volume e.g., '15%'" },
    colors: { 
      type: Type.ARRAY, 
      items: { type: Type.STRING },
      description: "Array of 3 hex color codes representing the drink visual"
    },
    moodInterpretation: { type: Type.STRING, description: "Psychological interpretation of the user's mood" },
    visualStyle: { 
      type: Type.STRING, 
      enum: ["glass", "bottle", "energy"],
      description: "The best visual container for this drink"
    }
  },
  required: ["name", "tagline", "description", "baseSpirit", "ingredients", "flavorProfile", "intensity", "abv", "colors", "moodInterpretation", "visualStyle"]
};

export const generateDrinkFromMood = async (moodText: string): Promise<DrinkRecipe> => {
  try {
    const model = "gemini-2.5-flash";
    const prompt = `
      You are an expert mixologist and empath. 
      Analyze the following user mood description: "${moodText}".
      Create a unique, abstract, and artistic cocktail recipe that conceptualizes this emotion.
      If the mood is calm/sad, lean towards deep blues/purples and 'bottle' or 'glass' style.
      If the mood is energetic/happy, lean towards bright yellows/oranges and 'energy' or 'glass' style.
      If the mood is complex/mysterious, lean towards smoke/fog effects and dark colors.
      
      Return a JSON object.
    `;

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: recipeSchema,
        temperature: 0.8 // High creativity
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    return JSON.parse(text) as DrinkRecipe;
  } catch (error) {
    console.error("Gemini API Error:", error);
    // Fallback data for robust UI if API fails (though we should avoid this in prod)
    throw error;
  }
};