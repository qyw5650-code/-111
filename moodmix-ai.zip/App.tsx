import React, { useState } from 'react';
import { AppState, DrinkRecipe } from './types';
import AnalyzingView from './components/AnalyzingView';
import ResultCard from './components/ResultCard';
import TextInputView from './components/TextInputView';
import { generateDrinkFromMood } from './services/geminiService';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [userText, setUserText] = useState('');
  const [recipe, setRecipe] = useState<DrinkRecipe | null>(null);

  const handleMoodSubmit = async (text: string) => {
    setUserText(text);
    setAppState(AppState.ANALYZING);

    try {
      const generatedRecipe = await generateDrinkFromMood(text);
      
      // Ensure the analyzing animation plays for at least a few seconds for effect
      setTimeout(() => {
        setRecipe(generatedRecipe);
        setAppState(AppState.RESULT);
      }, 4000); 

    } catch (error) {
      console.error("Failed to generate drink", error);
      setAppState(AppState.IDLE);
      alert("Something went wrong with the mixologist. Please try again.");
    }
  };

  const handleRetry = () => {
    setRecipe(null);
    setUserText('');
    setAppState(AppState.IDLE);
  };

  return (
    <div className="fixed inset-0 bg-black text-white overflow-hidden font-sans">
      {/* Abstract Animated Background for IDLE state */}
      {appState === AppState.IDLE && (
        <div className="absolute inset-0 z-0">
          <div className="absolute top-[-20%] left-[-10%] w-[500px] h-[500px] bg-purple-900/30 rounded-full blur-[120px] animate-blob"></div>
          <div className="absolute bottom-[-20%] right-[-10%] w-[600px] h-[600px] bg-blue-900/20 rounded-full blur-[120px] animate-blob animation-delay-4000"></div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="relative z-10 w-full h-full flex flex-col">
        {appState === AppState.IDLE && (
          <TextInputView onSubmit={handleMoodSubmit} />
        )}

        {appState === AppState.ANALYZING && (
          <AnalyzingView text={userText} />
        )}

        {appState === AppState.RESULT && recipe && (
          <ResultCard recipe={recipe} onRetry={handleRetry} />
        )}
      </div>
    </div>
  );
};

export default App;