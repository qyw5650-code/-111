import React, { useEffect, useState } from 'react';
import { DrinkRecipe } from '../types';
import { Share2, RefreshCw, Bookmark, Sparkles, Wind, Droplets } from 'lucide-react';

interface ResultCardProps {
  recipe: DrinkRecipe;
  onRetry: () => void;
}

const ResultCard: React.FC<ResultCardProps> = ({ recipe, onRetry }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Trigger entrance animation
    setTimeout(() => setIsVisible(true), 100);
  }, []);

  const gradientStyle = {
    background: `radial-gradient(circle at center, ${recipe.colors[0]}40, ${recipe.colors[1]}20, transparent 70%)`
  };

  const bottleColorStyle = {
    background: `linear-gradient(135deg, ${recipe.colors[0]}80 0%, ${recipe.colors[1]}80 50%, ${recipe.colors[2]}80 100%)`
  };

  return (
    <div className={`relative w-full h-full flex flex-col items-center overflow-y-auto no-scrollbar transition-opacity duration-1000 ${isVisible ? 'opacity-100' : 'opacity-0'}`}>
      
      {/* Dynamic Background Glow */}
      <div className="fixed inset-0 pointer-events-none transition-all duration-1000" style={gradientStyle}></div>

      {/* Header: Name */}
      <div className="mt-12 mb-6 text-center z-10 px-6">
        <p className="text-xs font-mono text-white/40 tracking-[0.2em] uppercase mb-2">Your Blend</p>
        <h1 className="text-4xl md:text-5xl font-serif font-bold text-white leading-tight drop-shadow-[0_0_15px_rgba(255,255,255,0.3)]">
          {recipe.name}
        </h1>
        <p className="text-lg text-white/70 font-light italic mt-2 font-serif">
          {recipe.tagline}
        </p>
      </div>

      {/* Visual Centerpiece (Procedural Bottle/Drink) */}
      <div className="relative w-full max-w-[300px] aspect-[3/4] flex items-center justify-center my-4 z-10 shrink-0">
        
        {/* Container Shape based on type */}
        <div className={`relative transition-all duration-1000 transform ${isVisible ? 'scale-100 translate-y-0' : 'scale-90 translate-y-10'}`}>
           {/* Glass/Bottle Silhouette */}
           <div className={`
             relative overflow-hidden backdrop-blur-sm border border-white/20 shadow-[0_0_30px_rgba(255,255,255,0.1)]
             ${recipe.visualStyle === 'bottle' ? 'w-32 h-64 rounded-t-full rounded-b-2xl' : ''}
             ${recipe.visualStyle === 'glass' ? 'w-40 h-40 rounded-b-full' : ''}
             ${recipe.visualStyle === 'energy' ? 'w-48 h-48 rounded-full blur-xl' : ''}
           `}>
             {/* Liquid Fill */}
             <div className="absolute inset-0 opacity-80" style={bottleColorStyle}></div>
             
             {/* Liquid Animation (Waves inside) */}
             <div className="absolute bottom-0 left-0 right-0 h-[120%] opacity-50 animate-[spin_8s_linear_infinite]"
                  style={{ borderRadius: '40%', background: 'rgba(255,255,255,0.2)', transform: 'translateY(10%) scale(1.5)' }}></div>
             <div className="absolute bottom-0 left-0 right-0 h-[120%] opacity-30 animate-[spin_6s_linear_infinite_reverse]"
                  style={{ borderRadius: '35%', background: 'rgba(255,255,255,0.1)', transform: 'translateY(10%) scale(1.6)' }}></div>

             {/* Bubbles */}
             <div className="absolute inset-0">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="absolute bg-white/40 rounded-full animate-bounce"
                       style={{
                         width: Math.random() * 6 + 2 + 'px',
                         height: Math.random() * 6 + 2 + 'px',
                         left: Math.random() * 100 + '%',
                         top: Math.random() * 100 + '%',
                         animationDuration: Math.random() * 3 + 2 + 's',
                         animationDelay: Math.random() * 2 + 's'
                       }}></div>
                ))}
             </div>
           </div>
        </div>
      </div>

      {/* Recipe Card */}
      <div className={`w-full max-w-md bg-white/5 backdrop-blur-xl border-t border-white/10 rounded-t-3xl p-8 z-20 mt-auto transition-transform duration-700 delay-300 ${isVisible ? 'translate-y-0' : 'translate-y-full'}`}>
        
        {/* Interpretation Quote */}
        <div className="mb-6 pb-6 border-b border-white/10">
          <p className="text-white/80 italic text-sm leading-relaxed font-serif">
            "{recipe.moodInterpretation}"
          </p>
        </div>

        {/* Flavor Profile Grid */}
        <div className="grid grid-cols-3 gap-4 mb-6 text-center">
            <div className="flex flex-col items-center">
              <span className="text-xs text-white/40 uppercase tracking-widest mb-1">Top</span>
              <span className="text-sm font-medium">{recipe.flavorProfile.top}</span>
            </div>
            <div className="flex flex-col items-center border-x border-white/10 px-2">
              <span className="text-xs text-white/40 uppercase tracking-widest mb-1">Body</span>
              <span className="text-sm font-medium">{recipe.flavorProfile.middle}</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-xs text-white/40 uppercase tracking-widest mb-1">Finish</span>
              <span className="text-sm font-medium">{recipe.flavorProfile.base}</span>
            </div>
        </div>

        {/* Details Row */}
        <div className="flex justify-between items-center bg-white/5 rounded-xl p-4 mb-6">
           <div className="flex items-center gap-3">
             <div className="p-2 bg-white/10 rounded-full">
               <Droplets size={16} />
             </div>
             <div>
               <p className="text-xs text-white/50">Base Spirit</p>
               <p className="text-sm font-semibold">{recipe.baseSpirit}</p>
             </div>
           </div>
           <div className="h-8 w-[1px] bg-white/10"></div>
           <div className="flex items-center gap-3">
             <div className="p-2 bg-white/10 rounded-full">
               <Wind size={16} />
             </div>
             <div>
               <p className="text-xs text-white/50">Intensity</p>
               <div className="w-16 h-1 bg-white/20 rounded-full mt-1">
                 <div className="h-full bg-white rounded-full" style={{ width: `${recipe.intensity}%` }}></div>
               </div>
             </div>
           </div>
        </div>

        {/* Ingredients List */}
        <div className="mb-8">
          <h3 className="text-xs font-mono text-white/40 uppercase mb-3">Composition</h3>
          <ul className="space-y-2">
            {recipe.ingredients.map((ing, i) => (
              <li key={i} className="flex items-center text-sm text-white/80">
                <span className="w-1.5 h-1.5 rounded-full bg-white/50 mr-3"></span>
                {ing}
              </li>
            ))}
          </ul>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-3 gap-3">
          <button className="col-span-1 py-4 flex flex-col items-center justify-center bg-white/5 rounded-2xl hover:bg-white/10 transition-colors active:scale-95 group">
             <Bookmark size={20} className="mb-1 text-white/70 group-hover:text-white" />
             <span className="text-[10px] uppercase tracking-wide opacity-50">Save</span>
          </button>
          <button className="col-span-1 py-4 flex flex-col items-center justify-center bg-white/5 rounded-2xl hover:bg-white/10 transition-colors active:scale-95 group">
             <Share2 size={20} className="mb-1 text-white/70 group-hover:text-white" />
             <span className="text-[10px] uppercase tracking-wide opacity-50">Share</span>
          </button>
          <button onClick={onRetry} className="col-span-1 py-4 flex flex-col items-center justify-center bg-white rounded-2xl text-black hover:bg-gray-200 transition-colors active:scale-95">
             <RefreshCw size={20} className="mb-1" />
             <span className="text-[10px] uppercase tracking-wide font-bold">New Mix</span>
          </button>
        </div>

      </div>
    </div>
  );
};

export default ResultCard;