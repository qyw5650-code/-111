import React, { useState } from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';

interface TextInputViewProps {
  onSubmit: (text: string) => void;
}

const TextInputView: React.FC<TextInputViewProps> = ({ onSubmit }) => {
  const [input, setInput] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim().length > 0) {
      onSubmit(input);
    }
  };

  const predefinedMoods = [
    "Peaceful but a bit tired",
    "Energetic and wild",
    "Melancholy rain vibes",
    "Anxious about tomorrow"
  ];

  return (
    <div className="flex flex-col h-full w-full max-w-md mx-auto p-6 pt-20">
      <div className="flex-1 flex flex-col justify-center">
        <h1 className="text-4xl font-serif font-bold mb-2">How is your<br/>spirit today?</h1>
        <p className="text-white/50 mb-8 font-light">Describe your moment or feeling. We will distill it into a flavor.</p>
        
        <form onSubmit={handleSubmit} className="relative group">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="I feel..."
            className="w-full bg-white/10 rounded-3xl p-6 pr-14 text-lg text-white placeholder-white/30 focus:outline-none focus:ring-2 focus:ring-white/20 focus:bg-white/15 transition-all resize-none h-40 backdrop-blur-md border border-white/5"
          />
          <button 
            type="submit"
            disabled={!input.trim()}
            className="absolute bottom-4 right-4 p-3 bg-white text-black rounded-full disabled:opacity-30 disabled:cursor-not-allowed hover:scale-105 active:scale-95 transition-all shadow-[0_0_20px_rgba(255,255,255,0.2)]"
          >
            <ArrowRight size={24} />
          </button>
        </form>

        <div className="mt-8">
           <p className="text-xs uppercase tracking-widest text-white/30 mb-4">Quick Select</p>
           <div className="flex flex-wrap gap-2">
             {predefinedMoods.map((mood) => (
               <button 
                 key={mood}
                 onClick={() => setInput(mood)}
                 className="px-4 py-2 rounded-full border border-white/10 text-sm text-white/60 hover:bg-white/10 hover:text-white transition-colors"
               >
                 {mood}
               </button>
             ))}
           </div>
        </div>
      </div>
      
      <div className="mt-auto py-6 flex justify-center opacity-40">
        <Sparkles size={16} className="animate-pulse mr-2" />
        <span className="text-xs font-mono">AI Mixologist Ready</span>
      </div>
    </div>
  );
};

export default TextInputView;