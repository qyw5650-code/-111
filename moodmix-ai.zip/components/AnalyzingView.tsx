import React, { useEffect, useRef, useState } from 'react';
import { EmotionData } from '../types';

interface AnalyzingViewProps {
  text: string;
}

const AnalyzingView: React.FC<AnalyzingViewProps> = ({ text }) => {
  const [phase, setPhase] = useState(0);
  
  // Simulated phases of analysis text
  useEffect(() => {
    const messages = [
      "Capturing your current moment...",
      "Analyzing emotional frequency...",
      "Extracting mood particles...",
      "Blending your emotional base...",
      "Harmonizing flavor notes..."
    ];
    
    let i = 0;
    const interval = setInterval(() => {
      i = (i + 1) % messages.length;
      setPhase(i);
    }, 1500);
    
    return () => clearInterval(interval);
  }, []);

  const messages = [
      "Capturing your current moment...",
      "Analyzing emotional frequency...",
      "Extracting mood particles...",
      "Blending your emotional base...",
      "Harmonizing flavor notes..."
  ];

  return (
    <div className="relative flex flex-col items-center justify-center h-full w-full overflow-hidden">
      {/* Background Ambient Glow */}
      <div className="absolute top-0 left-0 w-full h-full bg-black z-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-blue-500/20 rounded-full blur-[100px] animate-pulse"></div>
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-purple-500/10 rounded-full blur-[120px] animate-blob animation-delay-2000"></div>
      </div>

      {/* Central "Siri" Ripple Effect */}
      <div className="relative z-10 w-full max-w-md aspect-square flex items-center justify-center">
        {/* Core */}
        <div className="absolute w-20 h-20 bg-white/10 rounded-full blur-md animate-pulse"></div>
        
        {/* Ripples */}
        {[...Array(3)].map((_, i) => (
           <div 
             key={i}
             className="absolute border border-white/20 rounded-full opacity-0 animate-[ping_3s_ease-in-out_infinite]"
             style={{
               width: `${100 + i * 50}px`,
               height: `${100 + i * 50}px`,
               animationDelay: `${i * 0.5}s`
             }}
           />
        ))}
        
        {/* Orbiting Particles */}
        <div className="absolute w-full h-full animate-[spin_10s_linear_infinite]">
             <div className="absolute top-10 left-1/2 w-2 h-2 bg-cyan-400 rounded-full blur-[1px] shadow-[0_0_10px_cyan]"></div>
        </div>
        <div className="absolute w-3/4 h-3/4 animate-[spin_15s_linear_infinite_reverse]">
             <div className="absolute bottom-10 left-1/2 w-2 h-2 bg-pink-400 rounded-full blur-[1px] shadow-[0_0_10px_pink]"></div>
        </div>

        {/* Emotion Intensity Bar (Scanning) */}
        <div className="absolute bottom-10 w-64 h-1 bg-white/10 rounded-full overflow-hidden">
          <div className="h-full bg-gradient-to-r from-cyan-400 via-white to-pink-500 w-1/3 animate-[translateX_2s_ease-in-out_infinite] blur-sm"></div>
        </div>
      </div>

      {/* Text Prompts */}
      <div className="relative z-10 mt-8 text-center space-y-2">
        <h2 className="text-xl font-light text-white/90 tracking-wide animate-pulse">
          {messages[phase]}
        </h2>
        <p className="text-sm text-white/40 font-mono uppercase tracking-widest">
           Processing: {text.substring(0, 15)}{text.length > 15 ? '...' : ''}
        </p>
      </div>
    </div>
  );
};

export default AnalyzingView;