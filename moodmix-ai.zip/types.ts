export interface FlavorProfile {
  top: string;
  middle: string;
  base: string;
}

export interface DrinkRecipe {
  name: string;
  tagline: string; // e.g. "Midnight Cacao Mild"
  description: string;
  baseSpirit: string;
  ingredients: string[];
  flavorProfile: FlavorProfile;
  intensity: number; // 0-100
  abv: string; // e.g. "12%"
  colors: string[]; // Hex codes for gradient
  moodInterpretation: string;
  visualStyle: 'glass' | 'bottle' | 'energy';
}

export enum AppState {
  IDLE = 'IDLE',
  ANALYZING = 'ANALYZING',
  RESULT = 'RESULT',
}

export interface EmotionData {
  valence: number; // -1 (Negative) to 1 (Positive)
  arousal: number; // 0 (Calm) to 1 (Excited)
  dominantColor: string;
}